package hu.mate.zombik;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, choices, panel; TextView title, story, stats, location; SharedPreferences save;
    int hp=10; String pos="A"; HashMap<String,Integer> inv=new HashMap<>();
    static class Node { String loc,title,text; String[][] choices; Node(String l,String t,String x,String[][] c){loc=l;title=t;text=x;choices=c;} }
    HashMap<String,Node> n=new HashMap<>();
    int bg=Color.rgb(16,16,16), card=Color.rgb(28,28,28), fg=Color.rgb(235,235,235), muted=Color.rgb(160,160,160), border=Color.rgb(90,90,90);
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        save=getSharedPreferences("game",0);
        buildStory();
        load();
        showIntro();
    }

    void showIntro(){
        final FrameLayout intro=new FrameLayout(this);
        intro.setBackgroundColor(Color.BLACK);
        ImageView logo=new ImageView(this);
        logo.setImageResource(hu.mate.zombik.R.drawable.mate_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAlpha(0f);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.gravity=Gravity.CENTER;
        lp.leftMargin=28; lp.rightMargin=28; lp.topMargin=28; lp.bottomMargin=28;
        intro.addView(logo,lp);
        setContentView(intro);

        logo.animate().alpha(1f).setDuration(700).withEndAction(()->
            logo.animate().alpha(1f).setDuration(1100).withEndAction(()->
                logo.animate().alpha(0f).setDuration(700).withEndAction(()->{
                    buildUi();
                    render();
                }).start()
            ).start()
        ).start();
    }
    TextView tv(String s,int sp){ TextView v=new TextView(this); v.setText(s);v.setTextColor(fg);v.setTextSize(sp);v.setPadding(14,10,14,10); return v; }
    void buildUi(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,12,12,12);root.setBackgroundColor(bg);
      LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL); stats=tv("",12);location=tv("",12);bar.addView(stats,new LinearLayout.LayoutParams(0,-2,1));bar.addView(location);root.addView(bar);
      title=tv("",20);title.setTypeface(null,1);root.addView(title); story=tv("",16);story.setTextColor(Color.rgb(220,220,220));root.addView(story,new LinearLayout.LayoutParams(-1,0,1));
      choices=new LinearLayout(this);choices.setOrientation(LinearLayout.VERTICAL);root.addView(choices);
      LinearLayout menu=new LinearLayout(this); Button map=btn("🗺 TÉRKÉP"), invb=btn("🎒 INVENTORY"), reset=btn("↻ ÚJ JÁTÉK"); menu.addView(map,new LinearLayout.LayoutParams(0,-2,1));menu.addView(invb,new LinearLayout.LayoutParams(0,-2,1));menu.addView(reset,new LinearLayout.LayoutParams(0,-2,1));root.addView(menu);panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);root.addView(panel);setContentView(root);
      map.setOnClickListener(v->showMap()); invb.setOnClickListener(v->showInv()); reset.setOnClickListener(v->{newGame();render();});
    }
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(11);b.setAllCaps(false);b.setBackgroundColor(card);return b;}
    void buildStory(){
      n.put("A",new Node("LAKÓHÁZ","A MÁTÉ-ÁTOK","Máténak hívnak, és a Máté-átok ül rajtad.\n\nNem tudod pontosan, mit jelent ez, de most nem ez a legfontosabb problémád. A város három napja összeomlott. A rádió szerint a déli folyóparton egy helikopter várja a túlélőket. Oda kell jutnod.",new String[][]{{"Átkutatod a lakást","B"},{"Azonnal elindulsz","C"},{"Bekapcsolod a rádiót","D"}}));
      n.put("B",new Node("LAKÓHÁZ","A HÁLÓSZOBA","A szekrény mögött találsz egy régi hátizsákot. Van benne egy üveg víz és egy elemlámpa.",new String[][]{{"Elteszed és a lépcsőház felé mész","E"},{"Csak a vizet viszed","E"},{"Átkutatod még a konyhát","F"}}));
      n.put("C",new Node("UTCA","AZ ELSŐ LÉPÉS","Kilépsz az utcára. Egy parkoló autó mellett egy zombi áll. Nem vett észre. A túloldalon egy kisbolt, jobbra pedig egy sikátor látszik.",new String[][]{{"A kisbolt felé mész","G"},{"Megpróbálod kikerülni a zombit","H"},{"Visszamész a házba","A"}}));
      n.put("D",new Node("LAKÓHÁZ","A RÁDIÓ","A rádió recsegni kezd: „...folyópart... déli híd... mentés... napnyugta előtt...” Aztán elnémul.",new String[][]{{"Elindulsz az utcán","C"},{"Átkutatod a lakást","B"},{"Megpróbálod megjavítani a rádiót","F"}}));
      n.put("E",new Node("LÉPCSŐHÁZ","A SÖTÉT FOLYOSÓ","A lépcsőházban nincs áram. A földszintről kaparászás hallatszik. Fentről egy nyitott ablakon kijuthatnál a tetőre.",new String[][]{{"Lemész a földszintre","G"},{"Felmégy a tetőre","I"},{"Kinézel az ablakon","C"}}));
      n.put("F",new Node("KONYHA","HASZNOS HOLMI","A konyhaszekrényben találsz egy konzervet és egy régi elsősegélycsomagot.",new String[][]{{"Magaddal viszed","E"},{"Csak a gyógyszert viszed","E"},{"Otthagyod és továbbindulsz","C"}}));
      n.put("G",new Node("KISBOLT","A KIFOSZTOTT BOLT","A bolt szinte teljesen üres. A polc mögött azonban két konzervet és egy üveg vizet találsz. A hátsó ajtó egy másik utcára vezet.",new String[][]{{"Átkutatod a pénztár környékét","J"},{"A hátsó ajtón távozol","K"},{"Visszamész az utcára","H"}}));
      n.put("H",new Node("UTCA","A ZOMBI","Sikerül elosonnod mellette. Előtted egy buszmegálló, egy gyógyszertár és egy parkolóház áll.",new String[][]{{"Bemész a gyógyszertárba","L"},{"Átvágod a parkolóházat","M"},{"Elbújsz a buszmegállóban","N"}}));
      n.put("I",new Node("TETŐ","FELÜLRŐL","A tetőről látod a várost. A déli oldalon fekete füst száll fel. A folyópart felé vezető főút tele van roncsokkal.",new String[][]{{"A tűz felé indulsz","M"},{"A folyó irányát követed a háztetőkön","O"},{"Visszamész a lépcsőházba","E"}}));
      n.put("J",new Node("KISBOLT","A PULT MÖGÖTT","Egy régi rádióakkut és egy rozsdás kulcsot találsz.",new String[][]{{"Elteszed mindkettőt","K"},{"Csak a kulcsot viszed","K"},{"Otthagyod őket","K"}}));
      n.put("K",new Node("HÁTSÓ UTCA","A KERESZTEZŐDÉS","A kisbolt mögött három irányba lehet továbbmenni. Észak felől hörgések hallatszanak. Dél felől a folyó felől érkező szél fúj.",new String[][]{{"Dél felé, a folyóhoz","P"},{"A régi iskola felé","Q"},{"Az aluljárón keresztül","R"}}));
      n.put("L",new Node("GYÓGYSZERTÁR","NEM VAGY EGYEDÜL","Egy túlélő bújik meg. Azt mondja, az iskola mögött biztonságos út vezet a folyóhoz.",new String[][]{{"Segítesz neki","Q"},{"Otthagyod és továbbmész","P"},{"Átkutatod a gyógyszertárat","S"}}));
      n.put("M",new Node("PARKOLÓHÁZ","A SZINTEK KÖZÖTT","Sötét van. Egy autóban még van benzin, de a motor nem indul. A rámpa tetején egy ajtó vezet a következő utcára.",new String[][]{{"Megpróbálod beindítani az autót","T"},{"Felmégy a rámpán","P"},{"Átkutatod az autókat","U"}}));
      n.put("N",new Node("BUSZMEGÁLLÓ","TÚL SOKÁIG","A zombik hangja közeledik. Egy régi busz áll melletted, az ajtaja nyitva.",new String[][]{{"Felszállsz a buszra","V"},{"A park felé futsz","P"},{"Visszamész a gyógyszertárhoz","L"}}));
      n.put("O",new Node("HÁZTETŐK","RÖVIDÍTÉS","A háztetőkön gyorsabban haladsz. Egy helyen át kell ugranod egy másik épületre.",new String[][]{{"Megpróbálod az ugrást","P"},{"Lemész az utcára","K"},{"Visszafordulsz","I"}}));
      n.put("P",new Node("FOLYÓPART","A HÍD ELŐTT","Megérkezel a folyóhoz. A túloldalon reflektorok mozognak. A mentőcsapat ott van. A híd azonban tele van zombikkal.",new String[][]{{"Átkelsz a hídon","W"},{"Keresel egy csónakot","X"},{"Megkerülöd a hidat","Y"}}));
      n.put("Q",new Node("ISKOLA","A HÁTSÓ KAPU","Az iskola mögött egy régi szervizút vezet a folyóhoz, de a kapu zárva van.",new String[][]{{"Átkutatod az őrbódét","J"},{"Átmászol a kapun","P"},{"Megkeresed a másik bejáratot","Z"}}));
      n.put("R",new Node("ALULJÁRÓ","SÖTÉTBEN","Az aluljáróban bokáig ér a víz. Valami mozog a sötétben.",new String[][]{{"Átgázolsz rajta","P"},{"Felkapcsolod az elemlámpát","AA"},{"Visszafordulsz","K"}}));
      n.put("S",new Node("GYÓGYSZERTÁR","ELSŐSEGÉLY","Találsz kötszert és fájdalomcsillapítót.",new String[][]{{"Elteszed","P"},{"Használod most","P"},{"Csak a kötszert viszed","P"}}));
      n.put("T",new Node("PARKOLÓHÁZ","A MOTOR","A motor köhög egyet, aztán beindul. A benzinmutató majdnem üres.",new String[][]{{"A folyó felé vezetsz","P"},{"A főúton próbálsz gyorsabban menni","AB"},{"Otthagyod az autót","P"}}));
      n.put("U",new Node("PARKOLÓHÁZ","A CSOMAGTARTÓ","A csomagtartóban egy feszítővasat találsz.",new String[][]{{"Magaddal viszed","P"},{"Otthagyod","P"},{"A parkoló másik végébe mész","AB"}}));
      n.put("V",new Node("BUSZ","A JÁRAT","A busz belsejében három zombi vár. Azonnal észrevesznek.",new String[][]{{"Átverekeded magad rajtuk","P"},{"Kimenekülsz a hátsó ajtón","P"},{"Felkapaszkodsz a tetőre","AB"}}));
      n.put("W",new Node("HÍD","AZ UTOLSÓ SZAKASZ","A zombik között haladsz. A híd közepén egy katona integet a túloldalról.",new String[][]{{"Futni kezdesz","AC"},{"Lassan, csendben haladsz","AC"},{"Elbújsz egy roncs mögé","AD"}}));
      n.put("X",new Node("FOLYÓPART","A CSÓNAK","Találsz egy rozoga csónakot. Az evező hiányzik.",new String[][]{{"Beleülsz és sodródsz","AC"},{"Visszamész a hídhoz","W"},{"Keresel egy evezőt","AD"}}));
      n.put("Y",new Node("FOLYÓPART","KERÜLŐÚT","A folyópart mentén egy keskeny ösvény vezet tovább.",new String[][]{{"Követed az ösvényt","AC"},{"Felmégy a töltésre","AD"},{"Visszamész a hídhoz","W"}}));
      n.put("Z",new Node("ISKOLA","A PINCE","Az iskola pincéjében megtalálod a régi kulcs párját. A hátsó kapu nyitható.",new String[][]{{"Kinyitod a kaput","P"},{"Átkutatod még a pincét","J"},{"Visszamész az udvarra","Q"}}));
      n.put("AA",new Node("ALULJÁRÓ","A FÉNYBEN","Az elemlámpa fényében egy nagy patkány rohan el. A túloldalon már látod a folyót.",new String[][]{{"Továbbmész","P"},{"Megállsz és pihensz","P"},{"Visszafordulsz","K"}}));
      n.put("AB",new Node("FŐÚT","A MENEKÜLÉS","A gyorsabb út zajos. Sérülten érsz a folyópartra.",new String[][]{{"Tovább a hídhoz","W"},{"Elbújsz egy épületben","P"},{"A folyóparti ösvényt választod","Y"}}));
      n.put("AC",new Node("MENTÉSI ZÓNA","SIKERÜLT","A katona feléd rohan. „Máté? Gyorsan, szállj be!” A helikopter rotorjai felpörögnek. Túlélted az utat A pontból B-be.",new String[][]{}));
      n.put("AD",new Node("FOLYÓPART","AZ UTOLSÓ PERCEK","A mentőcsapat meglát. Egy jelzőrakétát lőnek fel. Már tudják, hogy itt vagy.",new String[][]{{"Integetsz nekik","AC"},{"A jelzőfényt követed","AC"},{"Futsz a hangár felé","AC"}}));
    }
    void render(){Node x=n.get(pos);title.setText(x.title);story.setText(x.text);location.setText("📍 "+x.loc);stats.setText("❤️ "+hp+"/10   🎒 "+invSize()+" tárgy");choices.removeAllViews();for(String[] c:x.choices){Button b=btn("▶ "+c[0]);b.setOnClickListener(v->go(c[1]));choices.addView(b);}panel.removeAllViews();save();}
    int invSize(){int z=0;for(int v:inv.values())z+=v;return z;}
    void go(String to){if(to.equals("AB")||to.equals("V")){hp=Math.max(1,hp-2);}if(to.equals("F")){inv.put("Konzerv",inv.getOrDefault("Konzerv",0)+1);inv.put("Elsősegély",1);}if(to.equals("G")){inv.put("Konzerv",inv.getOrDefault("Konzerv",0)+2);inv.put("Víz",inv.getOrDefault("Víz",0)+1);}if(to.equals("B"))inv.put("Elemlámpa",1);if(to.equals("J"))inv.put("Kulcs",1);if(to.equals("S")){inv.put("Kötés",1);inv.put("Gyógyszer",1);}if(to.equals("U"))inv.put("Feszítővas",1);pos=to;render();}
    void showInv(){panel.removeAllViews();TextView h=tv("🎒 INVENTORY",16);panel.addView(h);for(Map.Entry<String,Integer> e:inv.entrySet())panel.addView(tv(e.getKey()+" × "+e.getValue(),13));}
    void showMap(){panel.removeAllViews();panel.addView(tv("🗺 TÉRKÉP\n\n🌲 🌲 🏠 🌲 🌲 ❔ ❔\n🌲 📍 🛣 🏪 🌳 ❔ ❔\n❔ ❔ 🏫 🌳 🌉 ❔ ❔\n❔ ❔ 🌊 🚁 ❔ ❔ ❔\n\n📍 A = kiindulási pont\n🚁 B = mentési zóna",14));}
    void save(){save.edit().putString("pos",pos).putInt("hp",hp).apply();}
    void load(){pos=save.getString("pos","A");hp=save.getInt("hp",10);inv.put("Víz",1);inv.put("Konzerv",2);inv.put("Kés",1);}
    void newGame(){pos="A";hp=10;inv.clear();inv.put("Víz",1);inv.put("Konzerv",2);inv.put("Kés",1);save.edit().clear().apply();}
}
